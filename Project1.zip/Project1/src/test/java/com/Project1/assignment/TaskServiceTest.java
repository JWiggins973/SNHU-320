package com.Project1.assignment;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

class TaskServiceTest {

    // Variable
    private TaskService taskService;
    private Task task;

    @BeforeEach
        // Creates new task and task service before each test
    void setUp() {
        taskService = new TaskService();
        task = new Task( "1234567890" , "Clean Car", "Start on outside" );
    }

    @Test
        // Check if task added to task service
    void testAddTask() {
        Assertions.assertDoesNotThrow(() -> taskService.addTask(task));
    }

    @Test
        // Checks if task with same id can be added
    void testAddSameTask() {
        // add task
        taskService.addTask(task);

        // Add again
        Assertions.assertThrows(IllegalArgumentException.class, () -> taskService.addTask(task));
    }

    @Test
        // Helper function to check if task is not in data structure before add deleting or updating
    void testTaskDoesntExist() {
        // Looks for task in empty structure
        Assertions.assertThrows(IllegalArgumentException.class, () -> taskService.findTask(task.getTaskId()));
    }

    @Test
    // Helper function to check if task in data structure before  add or delete or updating
    void testTaskExist() {
        // add task to structure
        taskService.addTask(task);

        // Looks for task in structure
        Assertions.assertDoesNotThrow(() -> taskService.findTask(task.getTaskId()));
    }


    @Test
        // Checks find task returns correct task
    void testFindTask() {
        // add task
        taskService.addTask(task);

        // Task added to task service is correct
        Assertions.assertEquals(task, taskService.findTask(task.getTaskId()));
    }

    @Test
        // Check if task is successfully removed
    void testRemoveTask() {
        // Add task
        taskService.addTask(task);
        // Remove task
        taskService.removeTask(task.getTaskId());

        // Trys to find deleted task exception thrown
        Assertions.assertThrows(IllegalArgumentException.class, () -> taskService.findTask(task.getTaskId()));
    }

    @Test
        // Checks if task name is updated
    void testUpdateTaskName() {
        // Add task
        taskService.addTask(task);
        // Update task name
        taskService.updateTaskName(task.getTaskId(), "Dont Clean Car");

        // Checks if name matches updated name
        Assertions.assertEquals("Dont Clean Car", task.getTaskName());
    }

    @Test
        // Checks if task description successfully updated
    void testUpdateTaskDescription() {
        // Add task
        taskService.addTask(task);
        // Update task name
        taskService.updateTaskDescription(task.getTaskId(), "Dont forget to clean driveway after");

        // Checks if task description match
        Assertions.assertEquals("Dont forget to clean driveway after", task.getTaskDescription());
    }
}
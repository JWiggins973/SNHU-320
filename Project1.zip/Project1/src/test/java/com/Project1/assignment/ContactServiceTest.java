package com.Project1.assignment;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ContactServiceTest {
    // variables
    private ContactService contactService;
    private Contact contact;

    @BeforeEach
    void setUp() {
        contactService = new ContactService();
        contact = new Contact("00000001", "Jermaine", "Wiggins",
                "1111111111", "123456789");

    }

    @Test
        // Test if contact is added to contact services
    void testAddContact() {

        // Adding contact
        Assertions.assertDoesNotThrow(() -> contactService.addContact(contact));
    }

    @Test
        // Test if same contact or contact with same iD can be added twice
    void testAddSameContact() {
        // Add contact
        contactService.addContact(contact);

        // adding contact with same id twice
        Assertions.assertThrows(IllegalArgumentException.class, () -> contactService.addContact(contact));
    }

    @Test
        // Test if helper method correctly verifies if contact is in contact services
    void testCheckContact() {
        // if illegal argument thrown check contact can't find contact to delete
        //because contact doesn't exist in contactServices
        Assertions.assertThrows(IllegalArgumentException.class, () -> contactService.deleteContact("00000001"));

    }

    @Test
        // Test get contact returns correct contact
    void testGetContact() {
        // Add contact
        contactService.addContact(contact);
        // No exception thrown when searching for contact in data structure
        Assertions.assertDoesNotThrow(() -> contactService.getContact("00000001"));
    }

    @Test
        // Test if contact added was successfully deleted
    void testDeleteContact() {
        //add contact
        contactService.addContact(contact);

        //delete contact
        contactService.deleteContact("00000001");

        //trys to find contact in contactServices throws illegal argument if not found
        Assertions.assertThrows(IllegalArgumentException.class, () -> contactService.getContact("00000001"));
    }

    @Test
        // Test if firstName successfully updated
    void testUpdateContactFirstName() {
        contactService.addContact(contact);
        contactService.updateContactFirstName("00000001", "newName");
        Assertions.assertEquals("newName", contact.getFirstName());
    }

    @Test
        // Test if lastName successfully updated
    void testUpdateContactLastName() {
        contactService.addContact(contact);
        contactService.updateContactLastName("00000001", "lastName");
        Assertions.assertEquals("lastName", contact.getLastName());
    }

    @Test
        // Test if phoneNumber successfully updated
    void testUpdatePhoneNumber() {
        contactService.addContact(contact);
        contactService.updatePhoneNumber("00000001", "newNumberr");
        Assertions.assertEquals("newNumberr", contact.getPhoneNumber());
    }

    @Test
        // Test if address successfully updated
    void testUpdateAddress() {
        contactService.addContact(contact);
        contactService.updateAddress("00000001", "newAddress");
        Assertions.assertEquals("newAddress", contact.getAddress());
    }
}
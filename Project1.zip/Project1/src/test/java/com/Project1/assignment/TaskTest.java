package com.Project1.assignment;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;
import static org.junit.jupiter.api.Assertions.*;


class TaskTest {

    private Task task;

    // Run before sets up new task
    @BeforeEach
    void setUp() {
        task = new Task( "1234567890" , "Clean Car", "Start on outside" );
    }

    @Test
        // Check if task ID matches correct value
    void testTaskClassId() {
        assertEquals("1234567890", task.getTaskId());
    }

    @Test
        // Checks if id null throw exception
    void testSetTaskId() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Task( null,
                "Clean Car", "Start on outside"));
    }

    @Test
        // Check if task name returns correct values
    void testTaskClassName() {
        assertEquals("Clean Car", task.getTaskName());
    }

    @Test
        // Checks if task name null throws exception
    void testSetTaskNameNull() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> task.setTaskName(null));
    }

    @Test
        // Checks if task name greater than 20 characters throws exception
    void testSetTaskNameLength() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> task.setTaskName("Clean Car and the driveway."));
    }

    @Test
        // Check if task description returns correct values
    void testTaskClassDescription() {
        assertEquals("Start on outside", task.getTaskDescription());
    }

    @Test
        // Check if task description null throws exception
    void testSetTaskDescriptionNull() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> task.setTaskDescription(null));
    }

    @Test
        // Checks if task description greater than 50
    void testSetTaskDescriptionLength() {
        Assertions.assertThrows(IllegalArgumentException.class, () ->
                task.setTaskDescription("Start on outside and dont forget to clean the trunk and under the seats"));
    }
}
package com.Project1.assignment;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class AppointmentServiceTest {

    // Variables
    private Appointment appointment;
    private AppointmentService appointmentService;

    @BeforeEach
        // Set up new appointment and appointment service before each test
    void setUp() {
        appointment = new Appointment("123456789", 6, 6, 2025,
                "Dentist appointment");
        appointmentService = new AppointmentService();
    }

    @Test
        // Test if appointment is added to appointment services
    void testAddAppointment() {
        Assertions.assertDoesNotThrow(() -> appointmentService.addAppointment(appointment));
    }

    @Test
        // Test if same appointment can be added twice
    void testAddAppointmentException() {
        appointmentService.addAppointment(appointment);
        Assertions.assertThrows(IllegalArgumentException.class, () -> appointmentService.addAppointment(appointment));
    }

    @Test
        // Test if appointment can be found if not added
    void testFindAppointmentNotFound() {
        // Exception thrown and appointment is not found
        Assertions.assertThrows(IllegalArgumentException.class, () -> appointmentService.findAppointment(appointment.getAppointmentId()));
    }

    @Test
        // Test if appointment can be found after adding
    void testFindAppointment() {
        appointmentService.addAppointment(appointment);

        // Returns correct appointment
        assertEquals(appointment, appointmentService.findAppointment(appointment.getAppointmentId()));
    }

    @Test
        // Test if appointment is successfully deleted
    void testDeleteAppointment() {
        appointmentService.addAppointment(appointment);
        Assertions.assertDoesNotThrow(() -> appointmentService.deleteAppointment(appointment.getAppointmentId()));
    }

    @Test
        // Delete appointment throws exception when nothing to delete
    void testDeleteAppointmentNotFound() {
        // Empty appointmentServices
        Assertions.assertThrows(IllegalArgumentException.class, () -> appointmentService.deleteAppointment(
                appointment.getAppointmentId()));
    }
}


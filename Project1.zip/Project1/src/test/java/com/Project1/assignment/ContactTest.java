package com.Project1.assignment;

import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;




class ContactTest {

    // variable
    private Contact contact;

    @BeforeEach
    // create new contact
    void setUp() {
        contact = new Contact("00000001", "Jermaine", "Wiggins",
                "1111111111", "123456789");
    }

    @Test
        // Test contact class returns correct id
    void testContactId() {
        assertEquals("00000001", contact.getContactId());
    }

    @Test
        // Test that an exception is thrown when contactId null
    void testContactIdNotNull() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Contact(null, null, "Wiggins",
                "1111111111", "123456789"));
    }

    @Test
        // Test that an exception is thrown when contactId greater than 10
    void testContactIdGreaterTen() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> new Contact("0123456789 ", null, "Wiggins",
                "1111111111", "123456789"));
    }

    @Test
    // Test first name returns correct value
    void testContactFirstName() {
        assertEquals("Jermaine", contact.getFirstName());
    }

    @Test
        // Test that an exception is thrown when first name null
    void testFirstNameNotNull() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> contact.setFirstName(null));
    }

    @Test
        // Test that an exception is thrown when first name greater than 10 characters
    void testFirstNameGreaterTen() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> contact.setFirstName("Jermaineeee"));
    }

    @Test
        // Test last name returns correct value
    void testContactLastName() {
        assertEquals("Wiggins", contact.getLastName());
    }


    @Test
        // Test that an exception is thrown when last name null
    void setLastNameNotNull() {
        Assertions.assertThrows(IllegalArgumentException.class, ()->contact.setLastName(null));
    }


    @Test
        // Test that an exception is thrown when last name greater than 10 characters
    void setLastNameNotGreaterTen() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> contact.setLastName("Wiggins8900"));
    }

    @Test
        // Test phone number returns correct value
    void testPhoneNumber() {
        assertEquals("1111111111", contact.getPhoneNumber());
    }


    @Test
        // Test that an exception is thrown when phone number null
    void phoneNumberNotNull() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> contact.setPhoneNumber(null));
    }

    @Test
        // Test that an exception is thrown when phone number doesn't equal 10 characters
    void phoneNumberNotEqualTen() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> contact.setPhoneNumber("1"));
    }

    @Test
        // Test address returns correct value
    void testAddress() {
        assertEquals("123456789", contact.getAddress());
    }

    @Test
        // Test that an exception is thrown when address null
    void addressNotNull() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> contact.setAddress(null));
    }

    @Test
        // Test that an exception is thrown when address greater than 30 characters
    void addressGreaterThirty() {
        Assertions.assertThrows(IllegalArgumentException.class, () -> contact.setAddress("123456789 123456789 123456789 123456789"));
    }
}


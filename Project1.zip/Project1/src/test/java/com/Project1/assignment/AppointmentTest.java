package com.Project1.assignment;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Calendar;
import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class AppointmentTest {

    // Variables
    private Appointment appointment;

    @BeforeEach
    // Set up new appointment before each test
    void setUp() {
        appointment = new Appointment("123456789", 6, 6, 2025,
                "Dentist appointment");
    }

    @Test
        // Test if appointment Id returns correct value
    void testAppointmentId() {
        assertEquals("123456789", appointment.getAppointmentId());
    }

    @Test
        // Test if exception thrown when appointment id null
    void testAppointmentIdNull() {
        Assertions.assertThrows(IllegalArgumentException.class, ()-> appointment = new Appointment(null,
                6, 6, 2025, "Dentist appointment"));
    }

    @Test
        // Test appointment id greater than 10 throws exception
    void testAppointmentIdLength() {
        Assertions.assertThrows(IllegalArgumentException.class, ()-> appointment = new Appointment(
                "12345678901", 6, 6, 2025, "Dentist appointment"));
    }

    @Test
        // Test if appointment returns correct values
    void testAppointmentDate() {
        // Create the expected appointment date (June 6, 2025)
        Calendar calendar = Calendar.getInstance();
        calendar.set(2025, Calendar.JUNE, 6, 0 ,0, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        Date expectedDate  = calendar.getTime();

        // Check if expected date matches actual date
        assertEquals(expectedDate, appointment.getAppointmentDate());
    }


    @Test
        // Checks  exception thrown when date is in the past
    void testSetAppointmentDate() {
        Assertions.assertThrows(IllegalArgumentException.class, ()-> appointment.setAppointmentDate(1,1,
                2025));
    }

    @Test
        // Test if appointment description returns correct value
    void testAppointmentDescription() {
        assertEquals("Dentist appointment", appointment.getAppointmentDescription());
    }

    @Test
        // Test appointment description null throws exception
    void testSetAppointmentDescriptionNull() {
        Assertions.assertThrows(IllegalArgumentException.class, ()-> appointment.setAppointmentDescription(null));
    }

    @Test
        // Test appointment description length > 50 throws exception
    void testAppointmentDescriptionLength() {
        Assertions.assertThrows(IllegalArgumentException.class, ()-> appointment.setAppointmentDescription(
                "Dentist appointment is always fun arent they!!!!!!!!!!!!!!!!!!!!!!!!!!"));
    }


}
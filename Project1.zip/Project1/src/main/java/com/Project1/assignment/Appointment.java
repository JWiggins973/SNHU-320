package com.Project1.assignment;

import java.util.Calendar;
import java.util.Date;

public class Appointment {

    // Variables
    private final String appointmentId; // immutable field
    private Date appointmentDate;
    private String appointmentDescription;

    // Constructor
    public Appointment(String appointmentId, int month, int day, int year, String appointmentDescription) {
        // check if appointmentId is null and greater than 10 characters
        if (appointmentId == null || appointmentId.length() > 10 ) {
            throw new IllegalArgumentException("appointmentId cannot be null or longer than 10 characters");
        }

        // Set variables
        this.appointmentId = appointmentId;
        setAppointmentDate(month, day, year);
        setAppointmentDescription(appointmentDescription);
    }

    // Getters

    // Returns appointment Id
    public String getAppointmentId() {
        return appointmentId;
    }

    // Returns appointment date
    public Date getAppointmentDate() {
        return appointmentDate;
    }

    // Returns appointment description
    public String getAppointmentDescription() {
        return appointmentDescription;
    }

    // Setters

    // Sets and validates appointment date
    public void setAppointmentDate(int month, int day, int year) {
        // create new calendar instance
        Calendar calendar = Calendar.getInstance();

        // Set date minus 1 from  month start count from 0
        calendar.set(year, month - 1, day, 0, 0,0);

        // Set milliseconds
        calendar.set(Calendar.MILLISECOND, 0);

        // Gets date from calendar
        Date appointmentDate = calendar.getTime();

        // Checks if null because requirement but can never be null because setting above
        if (appointmentDate == null ) {
            throw new IllegalArgumentException("AppointmentDate cannot be null");
        }
        // Check if appointment is a date in the past
        if (appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("AppointmentDate cannot be in the past");
        }
        this.appointmentDate = appointmentDate;
    }

    // Sets and validates appointment description
    public void setAppointmentDescription(String appointmentDescription) {
        // Checks if appointment description is null or greater than 50 characters
        if (appointmentDescription == null || appointmentDescription.length() > 50) {
            throw new IllegalArgumentException("AppointmentDescription cannot be null or longer than 50");
        }
        this.appointmentDescription = appointmentDescription;
    }
}


package com.Project1.assignment;

public class Main {
    public static void main(String[] args) {
        System.out.println("CS320 Project 1");
    }
}
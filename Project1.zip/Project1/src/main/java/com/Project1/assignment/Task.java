package com.Project1.assignment;

public class Task {

    // Variables
    private final String taskId; // immutable field
    String taskName;
    String taskDescription;

    // Constructor
    public Task(String taskId, String taskName, String taskDescription) {
        // Checks if task id, name, or desc null
        if (taskId == null) {
            throw new IllegalArgumentException("Task id cannot be null");
        }
        // Sets all variables if valid
        this.taskId = taskId;
        setTaskName(taskName);
        setTaskDescription(taskDescription);
    }

    // Setters

    // Sets task name
    public void setTaskName(String taskName) {
        // Checks if task name null
        if (taskName == null) {
            throw new IllegalArgumentException("Task name cannot be null");
        }
        // Checks if task name greater than 20 characters
        if (taskName.length() > 20) {
            throw new IllegalArgumentException("Task name cannot be longer than 20 characters");
        }
        this.taskName = taskName;
    }

    // Sets task description
    public void setTaskDescription(String taskDescription) {
        // Checks if task description null
        if (taskDescription == null) {
            throw new IllegalArgumentException("Task description cannot be null");
        }
        // Checks if task desc greater than 50 characters
        if (taskDescription.length() > 50) {
            throw new IllegalArgumentException("Task description cannot be longer than 50 characters");
        }
        this.taskDescription = taskDescription;
    }

    // Getters

    // Gets task id
    public String getTaskId() {
        return taskId;
    }

    // Gets task name
    public String getTaskName() {
        return taskName;
    }

    // Gets task description
    public String getTaskDescription() {
        return taskDescription;
    }

}

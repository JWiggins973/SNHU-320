package com.Project1.assignment;

import java.util.HashMap;


public class ContactService {
    // Define data structure
    // Hash map for fast lookup and insertions and deletes
    // No collision because key is tied to unique contact iD
    private final HashMap<String, Contact> contactsMap;

    // Constructor
    public ContactService() {
        contactsMap = new HashMap<>();
    }

    // Add contact to map
    public void addContact(Contact contact) {
        // If contact id in map don't add to hash map
        if(contactsMap.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Contact already exists in the data structure");
        }
        // If not add to map use id as key
        contactsMap.put(contact.getContactId(), contact);
    }

    // Find contact
    public Contact getContact(String contactId) {
        checkContact(contactId);
        return contactsMap.get(contactId);
    }

    // Delete contact
    public void deleteContact(String contactId) {
        checkContact(contactId);
        contactsMap.remove(contactId);
    }

    // Update contact first name
    public void updateContactFirstName(String contactId, String newFirstName) {
        checkContact(contactId);
        contactsMap.get(contactId).setFirstName(newFirstName);
    }

    // Update contact last name
    public void updateContactLastName(String contactId, String newLastName) {
        checkContact(contactId);
        contactsMap.get(contactId).setLastName(newLastName);
    }

    // Update contact phone number
    public void updatePhoneNumber(String contactId, String newPhoneNumber) {
        checkContact(contactId);
        contactsMap.get(contactId).setPhoneNumber(newPhoneNumber);
    }

    // Update contact address
    public void updateAddress(String contactId, String newAddress) {
        checkContact(contactId);
        contactsMap.get(contactId).setAddress(newAddress);
    }

    // Check if contact is in map
    // Helper method to check map before adding deleting or updating
    private void checkContact(String contactId) {
        // If not in map through exception
        if(!contactsMap.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact does not exist in the data structure");
        }
    }
}
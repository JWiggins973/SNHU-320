package com.Project1.assignment;

import java.util.HashMap;

public class AppointmentService {
    // Define data structure
    // Hash map for fast lookup and insertions and deletes
    // No collision because key is tied to unique contact iD
    private final HashMap<String, Appointment> appointmentMap;

    // Constructor
    public AppointmentService() {
        appointmentMap = new HashMap<>();
    }

    // Add appointment
    public void addAppointment(Appointment appointment) {
        if (appointmentMap.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("Appointment already exists in data structure");
        }
        // If not in data structure add use appointment id as key
        appointmentMap.put(appointment.getAppointmentId(), appointment);
    }

    // Find appointment
    public Appointment findAppointment(String appointmentId) {
        checkAppointmentExists(appointmentId);
        return appointmentMap.get(appointmentId);
    }

    // Delete appointment
    public void deleteAppointment(String appointmentId) {
        checkAppointmentExists(appointmentId);
        appointmentMap.remove(appointmentId);
    }

    // Private helper method to check if appointment in data structure
    private void checkAppointmentExists(String appointmentId) {
        if (!appointmentMap.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment does not exists in data structure");
        }
    }

}
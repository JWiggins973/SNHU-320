package com.Project1.assignment;

public class Contact {

    // Declare variables
    private final String contactId; // immutable field
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String address;


    // Constructor
    public Contact(String contactId, String firstName, String lastName, String phoneNumber, String address) {
        // Checks id contact id null
        if (contactId == null || contactId.isEmpty()) {
            throw new IllegalArgumentException("Contact ID cannot be null or empty");
        }
        // Checks if contact id less than 10 characters
        if (contactId.length() > 10){
            throw new IllegalArgumentException("Contact ID is too long");
        }
        // Sets all variables
        this.contactId = contactId;
        setFirstName(firstName);
        setLastName(lastName);
        setPhoneNumber(phoneNumber);
        setAddress(address);
    }

    // Getters

    // Gets contact id
    public String getContactId() {
        return contactId;
    }

    // Gets first name
    public String getFirstName() {
        return firstName;
    }

    // Gets last name
    public String getLastName() {
        return lastName;
    }

    // Gets phone number
    public String getPhoneNumber() {
        return phoneNumber;
    }

    // Gets address
    public String getAddress() {
        return address;
    }

    // Setters

    // Sets first name
    public void setFirstName(String firstName) {
        // Checks if first name is null before setting
        if (firstName == null || firstName.isEmpty()) {
            throw new IllegalArgumentException("First name cannot be null or empty");
        }
        // Checks if first name greater than 10 characters before setting
        if (firstName.length() > 10){
            throw new IllegalArgumentException("First name is too long");
        }
        this.firstName = firstName;
    }

    // Sets last name
    public void setLastName(String lastName) {
        // Checks if last name null before setting
        if (lastName == null || lastName.isEmpty()) {
            throw new IllegalArgumentException("Last name cannot be null or empty");
        }
        // Checks if last name more than 10 characters before setting
        if (lastName.length() > 10){
            throw new IllegalArgumentException("Last name is too long");
        }
        this.lastName = lastName;
    }

    // sets phone number
    public void setPhoneNumber(String phoneNumber) {
        // checks if phone number is null before setting
        if (phoneNumber == null || phoneNumber.isEmpty()) {
            throw new IllegalArgumentException("Phone number cannot be null or empty");
        }
        // checks if phone number is not equal to before setting
        if (phoneNumber.length() != 10){
            throw new IllegalArgumentException("Phone number has wrong number of digits");
        }
        this.phoneNumber = phoneNumber;
    }

    // sets address
    public void setAddress(String address) {
        // checks if address is null before setting
        if (address == null || address.isEmpty()) {
            throw new IllegalArgumentException("Address cannot be null or empty");
        }
        // checks if address more than 30 char before setting
        if (address.length() > 30){
            throw new IllegalArgumentException("Address is too long");
        }
        this.address = address;
    }

}

package com.Project1.assignment;

import java.util.HashMap;

public class TaskService {
    // Define data structure
    // Hash map for fast lookup and insertions and deletes
    // No collision because key is tied to unique task iD
    private final HashMap<String, Task> taskMap;

    // Constructor
    public TaskService() {
        taskMap = new HashMap<>();
    }

    // Add task to map
    public void addTask(Task task) {
        // Check if task exist in hash map
        if (taskMap.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task already exists in data structure");
        }
        // Add to hash map if not in map uses task id as key
        taskMap.put(task.getTaskId(), task);
    }

    // Find task in map
    public Task findTask(String taskId) {
        checkTaskExists(taskId);
        return taskMap.get(taskId);
    }

    // Delete task in map
    public void removeTask(String taskId) {
        checkTaskExists(taskId);
        taskMap.remove(taskId);
    }

    // Update task name
    public void updateTaskName(String taskId, String newName) {
        checkTaskExists(taskId);
        taskMap.get(taskId).setTaskName(newName);
    }

    // Update task description
    public void updateTaskDescription(String taskId, String newDescription) {
        checkTaskExists(taskId);
        taskMap.get(taskId).setTaskDescription(newDescription);
    }

    // Helper function to check if task id in map
    private void checkTaskExists(String taskId) {
        if (!taskMap.containsKey(taskId)) {
            throw new IllegalArgumentException("Task does not exists in data structure");
        }
    }

}

